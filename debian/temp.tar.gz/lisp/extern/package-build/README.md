# package-build

Here, we place the legacy [package-build][] package.


[package-build]: https://github.com/melpa/package-build
